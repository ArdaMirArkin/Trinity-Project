package com.trinitycollege.trinity

data class PlacesItem(
    val title: String,
    val subtitle: String,
    val imageResId: Int
)
