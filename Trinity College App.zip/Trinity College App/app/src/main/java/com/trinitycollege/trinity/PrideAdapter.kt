package com.trinitycollege.trinity

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PrideAdapter(private val items: List<PrideItem>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val TYPE_HEADER = 0
        private const val TYPE_ITEM = 1
    }


    class PrideHeaderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val headerImage: ImageView = itemView.findViewById(R.id.imagePrideHeader)
    }


    class PrideViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val img: ImageView = itemView.findViewById(R.id.newsImage)
        val title: TextView = itemView.findViewById(R.id.newsTitle)
        val desc: TextView = itemView.findViewById(R.id.newsDesc)
        val btn: Button = itemView.findViewById(R.id.btnReadMore)
    }

    override fun getItemViewType(position: Int): Int {
        return if (position == 0) TYPE_HEADER else TYPE_ITEM
    }

    override fun getItemCount(): Int = items.size + 1 // header + items

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == TYPE_HEADER) {
            val v = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_pride_header, parent, false)
            PrideHeaderViewHolder(v)
        } else {
            val v = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_pride, parent, false)
            PrideViewHolder(v)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

        if (getItemViewType(position) == TYPE_HEADER) return

        val item = items[position - 1] // itemlar 1'den başlıyor
        val h = holder as PrideViewHolder

        h.img.setImageResource(item.imageRes)
        h.title.text = item.title
        h.desc.text = item.description

        h.btn.setOnClickListener {

        }
    }
}
