package com.trinitycollege.trinity

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val navPrograms = findViewById<TextView>(R.id.navPrograms)
        val navPeople = findViewById<TextView>(R.id.navPeople)
        val navPlaces = findViewById<TextView>(R.id.navPlaces)
        val navPride = findViewById<TextView>(R.id.navPride)

        navPrograms.setOnClickListener {
            startActivity(Intent(this, ProgramsActivity::class.java))
        }

        navPeople.setOnClickListener {
            startActivity(Intent(this, PeopleActivity::class.java))
        }

        navPlaces.setOnClickListener {
            startActivity(Intent(this, PlacesActivity::class.java))
        }

        navPride.setOnClickListener {
            startActivity(Intent(this, PrideActivity::class.java))
        }
    }
}
