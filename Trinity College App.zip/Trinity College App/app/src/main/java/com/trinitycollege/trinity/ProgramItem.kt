package com.trinitycollege.trinity

data class ProgramItem(
    val title: String,
    val subtitle: String,
    val courses: List<String>,
    var expanded: Boolean = false
)
