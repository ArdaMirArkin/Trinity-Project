package com.trinitycollege.trinity

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PeopleAdapter(private val peopleList: List<PeopleItem>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val VIEW_TYPE_HEADER = 0
        private const val VIEW_TYPE_ITEM = 1
    }


    class PeopleHeaderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val headerImage: ImageView = itemView.findViewById(R.id.imagePeopleHeader)
    }


    class PeopleViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val image: ImageView = itemView.findViewById(R.id.imagePeople)
        val title: TextView = itemView.findViewById(R.id.textPeopleTitle)
        val subtitle: TextView = itemView.findViewById(R.id.textPeopleSubtitle)
        val readMoreButton: Button = itemView.findViewById(R.id.buttonPeopleReadMore)
    }

    override fun getItemCount(): Int = peopleList.size + 1   // +1 = header

    override fun getItemViewType(position: Int): Int {
        return if (position == 0) VIEW_TYPE_HEADER else VIEW_TYPE_ITEM
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == VIEW_TYPE_HEADER) {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_people_header, parent, false)
            PeopleHeaderViewHolder(view)
        } else {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_people, parent, false)
            PeopleViewHolder(view)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (getItemViewType(position) == VIEW_TYPE_HEADER) {
            // Şimdilik header sabit resim, ekstra bind gerek yok
            return
        }

        // position 1..n -> gerçek item indexi = position - 1
        val realPos = position - 1
        val item = peopleList[realPos]

        val peopleHolder = holder as PeopleViewHolder
        peopleHolder.image.setImageResource(item.imageResId)
        peopleHolder.title.text = item.title
        peopleHolder.subtitle.text = item.subtitle

        peopleHolder.readMoreButton.setOnClickListener {
            // Henüz link koymadıysan boş kalabilir
        }
    }
}
