package com.trinitycollege.trinity

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PlacesAdapter(private val placesList: List<PlacesItem>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val VIEW_TYPE_HEADER = 0
        private const val VIEW_TYPE_ITEM = 1
    }


    class PlacesHeaderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val headerImage: ImageView = itemView.findViewById(R.id.imagePlacesHeader)
    }


    class PlacesViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val image: ImageView = itemView.findViewById(R.id.imagePlaces)
        val title: TextView = itemView.findViewById(R.id.textPlacesTitle)
        val subtitle: TextView = itemView.findViewById(R.id.textPlacesSubtitle)
        val button: Button = itemView.findViewById(R.id.buttonPlacesReadMore)
    }

    override fun getItemCount(): Int = placesList.size + 1   // +1: header

    override fun getItemViewType(position: Int): Int {
        return if (position == 0) VIEW_TYPE_HEADER else VIEW_TYPE_ITEM
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == VIEW_TYPE_HEADER) {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_places_header, parent, false)
            PlacesHeaderViewHolder(view)
        } else {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_places, parent, false)
            PlacesViewHolder(view)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (getItemViewType(position) == VIEW_TYPE_HEADER) {

            return
        }

        val realPos = position - 1
        val item = placesList[realPos]

        val placeHolder = holder as PlacesViewHolder
        placeHolder.image.setImageResource(item.imageResId)
        placeHolder.title.text = item.title
        placeHolder.subtitle.text = item.subtitle

        placeHolder.button.setOnClickListener {

        }
    }
}
