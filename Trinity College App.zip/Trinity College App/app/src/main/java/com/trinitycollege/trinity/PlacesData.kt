package com.trinitycollege.trinity

object PlacesData {
    val placesList = listOf(
        PlacesItem(
            title = "Trinfo Reopens Building, Celebrates 25 Years of Serving the Community",
            subtitle = "Trinfo.Café was founded in 1999—when internet cafés were popular worldwide—to broaden access to the internet and tech skills for Trinity’s neighbors.",
            imageResId = R.drawable.logo
        ),
        PlacesItem(
            title = "Exploring Campus Architecture through Building Plans",
            subtitle = "Trinity College students recently had the opportunity to put down their textbooks and pick up historic building plans to learn about some of the most iconic structures on campus." +
                    "",
            imageResId = R.drawable.logo
        ),
        PlacesItem(
            title = "See the Winners of Trinity’s First Room of the Year Contest",
            subtitle = "Bantams with some of the best nests on campus have been named the winners of Trinity College’s first Room of the Year contest."
                    ,
            imageResId = R.drawable.logo
        ),
                PlacesItem(
                title = "Architectural Digest Names Trinity’s Campus Among the Most Beautiful in America",
        subtitle = "Trinity College has once again been named by Architectural Digest as one of the most beautiful college campuses in America.",
        imageResId = R.drawable.logo
    ),
        PlacesItem(
            title = "Core of Trinity College’s Campus Named to the National Register of Historic Places",
            subtitle = "The National Park Service designated an 11.4-acre rectangular area anchored by the Long Walk and Chapel as the Trinity College Long Walk Historic District with national importance.",
            imageResId = R.drawable.logo
        ),
    )
}
