package com.trinitycollege.trinity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class PeopleActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_people)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewPeople)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = PeopleAdapter(PeopleData.peopleList)
    }
}
