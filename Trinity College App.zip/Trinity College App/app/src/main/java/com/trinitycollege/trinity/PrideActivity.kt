package com.trinitycollege.trinity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class PrideActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pride)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewPride)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = PrideAdapter(PrideData.prideList)
    }
}
