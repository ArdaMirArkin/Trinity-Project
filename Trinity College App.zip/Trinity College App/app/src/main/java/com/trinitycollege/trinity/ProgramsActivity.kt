package com.trinitycollege.trinity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ProgramsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_programs)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewPrograms)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val programList = mutableListOf(
            ProgramItem(
                "Liberal Arts Program",
                "Broad education in humanities, arts, social sciences.",
                listOf(
                    "Philosophy",
                    "History",
                    "Creative Writing",
                    "Political Science",
                    "Psychology"
                )
            ),
            ProgramItem(
                "Engineering & Sciences",
                "Cutting-edge labs and real-world STEM experience.",
                listOf(
                    "Computer Science",
                    "Physics I & II",
                    "Robotics",
                    "Calculus",
                    "Linear Algebra"
                )
            ),
            ProgramItem(
                "Interdisciplinary Studies",
                "Customize your education across multiple fields.",
                listOf(
                    "Data Science",
                    "Digital Media",
                    "Cognitive Science",
                    "Environmental Studies"
                )
            )
        )

        val adapter = ProgramsAdapter(programList)
        recyclerView.adapter = adapter
    }
}
