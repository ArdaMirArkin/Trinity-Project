package com.trinitycollege.trinity

data class PeopleItem(
    val title: String,
    val subtitle: String,
    val imageResId: Int
)
