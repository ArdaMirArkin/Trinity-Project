package com.trinitycollege.trinity

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ProgramsAdapter(private val programList: MutableList<ProgramItem>) :
    RecyclerView.Adapter<ProgramsAdapter.ProgramViewHolder>() {

    class ProgramViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.textTitle)
        val subtitle: TextView = view.findViewById(R.id.textSubtitle)
        val btnMore: Button = view.findViewById(R.id.btnLearnMore)
        val courses: TextView = view.findViewById(R.id.textCourses)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProgramViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_program, parent, false)
        return ProgramViewHolder(view)
    }

    override fun onBindViewHolder(holder: ProgramViewHolder, position: Int) {
        val program = programList[position]

        holder.title.text = program.title
        holder.subtitle.text = program.subtitle

        // Expand / Collapse State
        holder.courses.visibility = if (program.expanded) View.VISIBLE else View.GONE
        holder.btnMore.text = if (program.expanded) "Hide" else "Learn More"

        if (program.expanded) {
            holder.courses.text = program.courses.joinToString("\n") { "- $it" }
        }

        holder.btnMore.setOnClickListener {
            program.expanded = !program.expanded
            notifyItemChanged(position)
        }
    }

    override fun getItemCount(): Int {
        return programList.size
    }
}
