package com.trinitycollege.trinity

data class ProgramModel(
    val name: String
)
