package com.trinitycollege.trinity

data class PrideItem(
    val title: String,
    val description: String,
    val imageRes: Int
)

object PrideData {

    val prideList = listOf(
        PrideItem(
            title = "Prepare to be proud to be a Bantam.",
            description = "Life on Campus",
            imageRes = R.drawable.logo
        ),
        PrideItem(
            title = "Trinity Receives Wide Recognition for Value to Students, Success of Alumni",
            description = "Positioned among America’s top liberal arts institutions...",
            imageRes = R.drawable.logo
        ),
        PrideItem(
            title = "Trinity College Contributes to Historic Gravitational-Wave Discovery",
            description = "Faculty and students played a major role in LIGO’s groundbreaking discovery.",
            imageRes = R.drawable.logo
        ),
        PrideItem(
            title = "The Chapel Singers Celebrate 200 Years",
            description = "Trinity College’s oldest student organization releases bicentennial album.",
            imageRes = R.drawable.logo
        ),
        PrideItem(
            title = "Trinity Men’s Rowing Wins National Championship",
            description = "The 1V8 crew wins the IRA Division III National Championship.",
            imageRes = R.drawable.logo
        ),
        PrideItem(
            title = "Trinity Men’s Basketball Wins First National Championship",
            description = "The fourth-ranked Trinity men's basketball team claims the title.",
            imageRes = R.drawable.logo
        ),
        PrideItem(
            title = "Trinity Women’s Squash Wins Back-to-Back Titles",
            description = "Trinity defeats Harvard 5-4 to secure the national championship.",
            imageRes = R.drawable.logo
        )
    )
}
