package com.trinitycollege.trinity

object PeopleData {

    val peopleList = listOf(
        PeopleItem(
            title = "Trinity Student Wins Beinecke Scholarship to Support Graduate Studies",
            subtitle = "Rose Molloy ’26 has been selected to receive a Beinecke Scholarship, which will support her continuing study of political science in graduate school.",
            imageResId = R.drawable.logo
        ),
        PeopleItem(
            title = "English Professor’s Debut Novel Named as Finalist for National Book Award",
            subtitle = "The debut novel by Trinity College Associate Professor of English Ethan Rutherford, 'North Sun: Or, the Voyage of the Whaleship Esther', has been named by the National Book Foundation as a finalist for the 2025 National Book Award for Fiction.",
            imageResId = R.drawable.logo
        ),
        PeopleItem(
            title = "Abroad with ‘The Bard’ for Shakespeare’s Official Birthday Celebration",
            subtitle = "Trinity College Associate Professor of English David Sterling Brown ’06 recently was invited to take part in England’s weeklong Shakespeare Birthday Celebration as its inaugural visiting scholar.",
            imageResId = R.drawable.logo
        ),
        PeopleItem(
            title = "Trinity Professor Receives Award for Civic Engagement and Grants for Research",
            subtitle = "Assistant Professor of Political Science Dang Do has received the 2025 Outstanding Civic Engagement Project award from the American Political Science Association, recognizing the success of the Voter Captain Project to increase voter turnout in Hartford’s underrepresented neighborhoods.",
            imageResId = R.drawable.logo
        ),
        PeopleItem(
            title = "Trinity Alumna Is Part of Pulitzer Prize-Winning Team of Journalists at ProPublica",
            subtitle = "Andrea Wise ’11 was part of the ProPublica team awarded the 2025 Pulitzer Prize for Public Service for work on reproductive health—news she shared immediately with her mentor, Professor Pablo Delano.",
            imageResId = R.drawable.logo
        ),
        PeopleItem(
            title = "Twins at Trin: Following Different Paths at the Same College",
            subtitle = "Twins attending Trinity College together always have family nearby—supporting each other while exploring different majors and career paths.",
            imageResId = R.drawable.logo
        )
    )
}
