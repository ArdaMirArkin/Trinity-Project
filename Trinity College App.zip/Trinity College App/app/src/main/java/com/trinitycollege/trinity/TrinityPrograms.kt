package com.trinitycollege.trinity

object TrinityPrograms {

    val list = listOf(
        ProgramModel("American Studies"),
        ProgramModel("Anthropology"),
        ProgramModel("Applied Mathematics"),
        ProgramModel("Art History"),
        ProgramModel("Biochemistry"),
        ProgramModel("Biology"),
        ProgramModel("Chemistry"),
        ProgramModel("Classical Studies"),
        ProgramModel("Computer Science"),
        ProgramModel("Economics"),
        ProgramModel("Engineering"),
        ProgramModel("English"),
        ProgramModel("Environmental Science"),
        ProgramModel("History"),
        ProgramModel("Language and Culture Studies"),
        ProgramModel("Mathematics"),
        ProgramModel("Music"),
        ProgramModel("Neuroscience"),
        ProgramModel("Philosophy"),
        ProgramModel("Physics"),
        ProgramModel("Political Science"),
        ProgramModel("Psychology"),
        ProgramModel("Public Policy"),
        ProgramModel("Religion"),
        ProgramModel("Sociology"),
        ProgramModel("Urban Studies"),
        ProgramModel("Women, Gender, and Sexuality"),
        ProgramModel("Writing, Rhetoric, and Media Arts")

    )
}
